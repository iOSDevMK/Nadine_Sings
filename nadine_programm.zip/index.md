# NADINE  
## Jazz · Bossa Nova · Chanson

---

## PROGRAMM – ÜBERSICHT

### Jazz & Blues
- Lover Man (Oh, Where Can You Be?)
- Black Coffee
- Night and Day
- It Had to Be You
- Lullaby of Birdland
- What a Difference a Day Made
- Have You Met Miss Jones?
- Love Me or Leave Me
- Softly, as in a Morning Sunrise
- Miss Celie’s Blues (Sister)

### Bossa Nova / Brasil
- Agua de Beber
- Corcovado
- A Felicidade
- The Gentle Rain

### Chanson Français
- Milord
- La Bohème
- Jardin d’Hiver
- Padam… Padam
- Dans ma rue
- Que reste-t-il de nos amours ?
- Sous le ciel de Paris
- C’est si bon

---

## JAZZ & BLUES

### Lover Man (Oh, Where Can You Be?)  
*1944 (USA) – Jimmy Davis, Roger Ramirez, Jimmy Sherman · Billie Holiday, Sarah Vaughan*

![Lover Man](images/jazz/lover-man.png)

“Lover Man” entstand während des Zweiten Weltkriegs und trägt die Einsamkeit dieser Zeit in sich. Der Song spricht nicht von Romantik, sondern von einem schmerzhaften Mangel an Nähe. Berühmt wurde er durch Billie Holiday, deren Interpretation den Titel zu einem nächtlichen Bekenntnis machte. Ihre Stimme klingt suchend und verletzlich. Musikalisch verlangt das Stück große Zurückhaltung und Vertrauen in die Stille. Es ist kein Lied für große Gesten, sondern für Momente, in denen das Publikum unwillkürlich den Atem anhält.

---

### Black Coffee  
*1948 (USA) – Sonny Burke, Paul Francis Webster · Peggy Lee, Ella Fitzgerald*

![Black Coffee](images/jazz/black-coffee.png)

“Black Coffee” ist der Klang schlafloser Nächte. Der Text zeichnet einfache Bilder: schwarzer Kaffee, Zigaretten, endlose Stunden ohne Schlaf. Peggy Lee prägte das Stück mit einer kühlen, kontrollierten Interpretation. Musikalisch bewegt sich der Song zwischen Blues und Jazzballade. Er lebt vom Understatement und von der Erkenntnis, dass Traurigkeit oft leise ist.

---

### Night and Day  
*1932 (USA) – Cole Porter · Frank Sinatra, Ella Fitzgerald*

![Night and Day](images/jazz/night-and-day.png)

Cole Porter schrieb “Night and Day” als Lied über eine Liebe ohne Abstand. Der Text beschreibt eine obsessive Hingabe, die keine Ruhe kennt. Harmonisch raffiniert und zeitlos, wurde der Song von Generationen neu interpretiert. Er erzählt weniger eine Geschichte als einen Zustand.

---

### It Had to Be You  
*1924 (USA) – Isham Jones, Gus Kahn · Billie Holiday, Harry Connick Jr.*

![It Had to Be You](images/jazz/it-had-to-be-you.png)

“It Had to Be You” ist ein früher Jazzstandard, der Wärme und Selbstironie verbindet. Der Song erzählt von einer Liebe, die trotz aller Zweifel unvermeidlich scheint. Er schafft Nähe und sofortige Verbindung zum Publikum.

---

### Lullaby of Birdland  
*1952 (USA) – George Shearing, George David Weiss · Ella Fitzgerald, Sarah Vaughan*

![Lullaby of Birdland](images/jazz/lullaby-of-birdland.png)

Benannt nach dem legendären New Yorker Jazzclub, ist “Lullaby of Birdland” eine Liebeserklärung an das Nachtleben des Jazz. Elegant, swingend und leicht, eignet sich der Song ideal als Auftakt eines Sets.

---

### What a Difference a Day Made  
*1934 (Mexico/USA) – María Grever · Dinah Washington*

![What a Difference a Day Made](images/jazz/what-a-difference-a-day-made.png)

Der Song erzählt von der plötzlichen Verwandlung durch Liebe. Innerhalb eines Tages wird aus Einsamkeit Glück. Dinah Washington machte ihn weltberühmt.

---

### Have You Met Miss Jones?  
*1937 (USA) – Richard Rodgers, Lorenz Hart · Frank Sinatra*

![Have You Met Miss Jones?](images/jazz/have-you-met-miss-jones.png)

Verspielt und harmonisch anspruchsvoll beschreibt dieser Song das Verliebtsein mit Augenzwinkern. Besonders bekannt für seine überraschenden Harmoniewechsel.

---

### Love Me or Leave Me  
*1928 (USA) – Walter Donaldson, Gus Kahn · Nina Simone*

![Love Me or Leave Me](images/jazz/love-me-or-leave-me.png)

Ein selbstbewusstes Statement für Klarheit und Haltung. Nina Simone verlieh dem Song seine kraftvolle, zeitlose Dimension.

---

### Softly, as in a Morning Sunrise  
*1928 (USA) – Sigmund Romberg, Oscar Hammerstein II · John Coltrane*

![Softly, as in a Morning Sunrise](images/jazz/softly-as-in-a-morning-sunrise.png)

Mit seinem markanten Moll-Charakter entfaltet der Song eine dunkle, dramatische Spannung und große Eleganz.

---

### Miss Celie’s Blues (Sister)  
*1985 (USA) – Quincy Jones, Rod Temperton, Lionel Richie · The Color Purple*

![Miss Celie’s Blues](images/jazz/miss-celies-blues.png)

Ein Song über Selbstermächtigung und Befreiung. Blues, Gospel und Soul verbinden sich zu einem kraftvollen Abschluss des Jazz- & Blues-Teils.

---

## BOSSA NOVA / BRASIL

*(Texte folgen)*

## CHANSON FRANÇAIS

*(Texte folgen)*